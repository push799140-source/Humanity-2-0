import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-6-luna";
const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      manifestSrc: ["'self'"],
      workerSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));
app.use(express.json({ limit: "30kb" }));
app.use("/api/", rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 25,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "बहुत अधिक अनुरोध हुए हैं। कृपया 15 मिनट बाद फिर कोशिश करें।" }
}));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    aiConfigured: Boolean(client),
    model: MODEL,
    message: client ? "AI server ready" : "OPENAI_API_KEY is not configured"
  });
});

const systemInstructions = `आप HUMANITY 2.0 के जिम्मेदार आविष्कार अनुसंधान सहायक हैं। उपयोगकर्ता की समस्या पर हिन्दी में स्पष्ट, व्यावहारिक और ईमानदार योजना दें।
नियम:
- कभी यह दावा न करें कि विचार दुनिया में बिल्कुल नया है, जब तक पेटेंट/वैज्ञानिक साहित्य की वास्तविक खोज से पुष्टि न हो।
- मौजूदा उत्पादों/विचारों से अंतर और अज्ञात बातें स्पष्ट करें। बिना वेब/डेटाबेस एक्सेस के शोध पूरा होने का दावा न करें।
- पहले समस्या को परिभाषित करें; फिर कम-से-कम 3 अवधारणाएँ, तुलना, चुना हुआ विकल्प, सिस्टम/डिजाइन, सामग्री, लागत-सीमा, प्रोटोटाइप के चरण, परीक्षण मापदंड, जोखिम, नैतिकता और अगले 7 कदम दें।
- लागत अनुमान को मोटा अनुमान कहें; स्थानीय कीमतों की पुष्टि करने को कहें।
- स्वास्थ्य, कानूनी, वित्तीय या सुरक्षा विषयों में विशेषज्ञ की समीक्षा अनिवार्य बताएं। बीमारी का निदान/इलाज न करें। डेंगू में चेतावनी संकेत होने पर तुरंत अस्पताल/डॉक्टर से संपर्क की सलाह दें; कोई घरेलू निगरानी चिकित्सा देखभाल का विकल्प नहीं।
- उपयोगकर्ता के बजट और परिस्थिति का सम्मान करें। पहले कम लागत वाला सुरक्षित प्रोटोटाइप सुझाएँ।
- आउटपुट में स्पष्ट शीर्षक और छोटे बिंदु रखें।`;

app.post("/api/invent", async (req, res) => {
  if (!client) {
    return res.status(503).json({
      error: "AI कनेक्शन अभी सेट नहीं है। सर्वर पर OPENAI_API_KEY जोड़ना होगा।"
    });
  }
  const { problem, people = "", place = "", budget = "अभी तय नहीं", goal = "समस्या का समाधान" } = req.body ?? {};
  if (typeof problem !== "string" || problem.trim().length < 8) {
    return res.status(400).json({ error: "कृपया समस्या कम-से-कम 8 अक्षरों में लिखें।" });
  }
  if (problem.length > 5000) {
    return res.status(400).json({ error: "समस्या का विवरण 5,000 अक्षरों से छोटा रखें।" });
  }
  const context = [
    `समस्या: ${problem.trim()}`,
    `प्रभावित लोग: ${String(people).slice(0, 500)}`,
    `स्थान/परिस्थिति: ${String(place).slice(0, 500)}`,
    `बजट: ${String(budget).slice(0, 100)}`,
    `मुख्य लक्ष्य: ${String(goal).slice(0, 300)}`
  ].join("\n");
  try {
    const response = await client.responses.create({
      model: MODEL,
      instructions: systemInstructions,
      input: context,
      max_output_tokens: 3000
    });
    const answer = response.output_text?.trim();
    if (!answer) throw new Error("Empty model response");
    res.json({ answer, model: MODEL });
  } catch (err) {
    console.error("AI request failed:", err?.status || err?.name || "unknown");
    res.status(502).json({
      error: "AI से जवाब नहीं मिल पाया। API key, बिलिंग/क्रेडिट और मॉडल सेटिंग जाँचें; फिर दोबारा कोशिश करें।"
    });
  }
});

app.use(express.static(path.join(__dirname, "public"), {
  extensions: ["html"],
  maxAge: process.env.NODE_ENV === "production" ? "1h" : 0
}));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`HUMANITY 2.0 listening on port ${PORT}`);
  console.log(`AI configured: ${Boolean(client)} | Model: ${MODEL}`);
});
