# HUMANITY 2.0 — AI Invention Lab

यह प्रोजेक्ट एक मोबाइल-फ्रेंडली PWA (ऐप-जैसा वेब ऐप) और Node.js backend है। AI API key केवल server environment में रहती है; browser को key नहीं भेजी जाती।

## जरूरी चीजें
- Node.js 20 या नया
- OpenAI API key और API billing/credits
- Hosting account (उदाहरण: Render) — सार्वजनिक URL के लिए

## अपने कंप्यूटर पर चलाएँ
1. ZIP खोलें।
2. इस फोल्डर में terminal खोलें।
3. `npm install`
4. `.env.example` की कॉपी बनाकर `.env` नाम दें।
5. `.env` में `OPENAI_API_KEY=...` भरें। API key किसी से साझा न करें।
6. `npm start`
7. ब्राउज़र में `http://localhost:3000` खोलें।

## Replit पर प्रकाशित करें (फोन से भी)
1. ZIP फाइल डाउनलोड करके Extract करें, या Replit में नया Node.js project बनाकर इस ZIP की फाइलें upload/import करें।
2. Replit Agent में `REPLIT_SETUP_HINDI.txt` का पूरा निर्देश paste करें।
3. Shell में `npm install` और फिर `npm start` चलाएँ। Replit का Run बटन भी यही command चलाए।
4. Replit के Secrets में `OPENAI_API_KEY` नाम से अपनी OpenAI API key जोड़ें। Key को चैट, HTML या source code में न डालें।
5. `OPENAI_MODEL` वैकल्पिक secret के रूप में `gpt-6-luna` रखें। यह Responses API के उपलब्ध model IDs में है।
6. ऐप का `/api/health` खोलें। `aiConfigured: true` दिखने पर server ने key पढ़ ली है।
7. Replit Deploy/Publish करें। HTTPS live URL मिलने पर Android Chrome में खोलें → ⋮ → Add to Home screen / Install app।

## Render पर प्रकाशित करें
1. पूरा फोल्डर अपने GitHub repository में डालें।
2. Render में New → Blueprint चुनकर repository जोड़ें। `render.yaml` सेवा सेट करेगा।
3. Render के Environment में `OPENAI_API_KEY` नाम से अपनी key सुरक्षित रूप से डालें।
4. Deploy करें। Deploy पूरा होने पर Render URL खोलें।
5. `/api/health` पर `aiConfigured: true` दिखना चाहिए।

## ऐप की तरह इंस्टॉल
सार्वजनिक HTTPS URL खुलने के बाद Android Chrome में ⋮ → Add to Home screen / Install app चुनें। यह PWA है, Play Store पर प्रकाशित native APK नहीं।

## सुरक्षा
- `.env` कभी GitHub पर अपलोड न करें।
- API key केवल hosting provider के secret/environment settings में रखें।
- API उपयोग पर शुल्क लग सकता है; OpenAI dashboard में usage limits/budget सेट करें।
- डिफॉल्ट मॉडल `gpt-6-luna` है; जरूरत पड़ने पर `OPENAI_MODEL` बदल सकते हैं।
- API key जोड़ना, hosting पर deploy करना और API billing सक्रिय करना उपयोगकर्ता के अपने अकाउंट से होगा।

## अभी क्या शामिल है
- Hindi UI
- Node/Express backend
- OpenAI Responses API integration
- Rate limiting, request size limit, Helmet security headers
- PWA manifest, service worker और app icon
- DENGUARD प्रोजेक्ट प्रॉम्प्ट
- रिपोर्ट कॉपी/डाउनलोड

## सीमाएँ
यह starter app पूर्ण commercial product नहीं है। इसमें अभी user login, cloud database, payment, admin panel, audit logging, abuse monitoring, automated patent search और medical device validation नहीं हैं। सार्वजनिक उपयोग से पहले इनकी जरूरत का मूल्यांकन करें।
