const $=id=>document.getElementById(id);
let latest="", installPrompt=null;
async function checkServer(){
  try{const r=await fetch("/api/health");const d=await r.json();$("status").textContent=d.aiConfigured?"● AI सर्वर कनेक्टेड":"● API key बाकी है";$("status").style.color=d.aiConfigured?"#48e0a4":"#ffd166";}
  catch{$("status").textContent="● सर्वर से संपर्क नहीं";$("status").style.color="#ff7b86";}
}
async function invent(){
 const problem=$("problem").value.trim();if(problem.length<8){$("message").textContent="कृपया समस्या कम-से-कम 8 अक्षरों में लिखें।";return;}
 const btn=$("generate");btn.disabled=true;btn.textContent="AI विचार तैयार कर रहा है…";$("message").textContent="कृपया प्रतीक्षा करें।";$("result").textContent="AI आपकी समस्या का विश्लेषण कर रहा है…";
 try{
  const r=await fetch("/api/invent",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({problem,people:$("people").value,place:$("place").value,budget:$("budget").value,goal:$("goal").value})});
  const d=await r.json();if(!r.ok)throw new Error(d.error||"अनुरोध पूरा नहीं हुआ।");
  latest=d.answer;$("result").textContent=latest;$("message").textContent="AI ने योजना तैयार की। अब विशेषज्ञ समीक्षा और परीक्षण करें।";localStorage.setItem("humanity2_last",latest);
 }catch(e){$("result").textContent="";$("message").textContent=e.message;}
 finally{btn.disabled=false;btn.textContent="AI से आविष्कार डिजाइन करवाएँ ✦";}
}
$("generate").addEventListener("click",invent);
$("dengue").addEventListener("click",()=>{$("problem").value="डेंगू में मरीज की हालत बिगड़ने के शुरुआती संकेत परिवार समय पर कैसे पहचान सके और डॉक्टर तक सही जानकारी कैसे पहुँचे? एक सुरक्षित, कम लागत वाला निगरानी और देखभाल समन्वय प्रोटोटाइप डिजाइन करें।";$("people").value="डेंगू मरीज, परिवार और देखभालकर्ता";$("place").value="घर और प्राथमिक स्वास्थ्य केंद्र";$("budget").value="₹0–₹500";$("goal").value="कम लागत में जीवन बचाना";invent();});
$("copy").addEventListener("click",async()=>{if(!latest)return $("message").textContent="पहले AI परिणाम तैयार करें।";try{await navigator.clipboard.writeText(latest);$("message").textContent="कॉपी हो गया।";}catch{$("message").textContent="कॉपी की अनुमति नहीं मिली।";}});
$("download").addEventListener("click",()=>{if(!latest)return $("message").textContent="पहले AI परिणाम तैयार करें।";const a=document.createElement("a");const u=URL.createObjectURL(new Blob([latest],{type:"text/plain;charset=utf-8"}));a.href=u;a.download="HUMANITY-2.0-Invention-Report.txt";a.click();URL.revokeObjectURL(u);});
$("clear").addEventListener("click",()=>{$("problem").value="";$("result").textContent="अपनी समस्या लिखकर ऊपर बटन दबाएँ।";$("message").textContent="";latest="";});
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;$("install").classList.remove("hidden");});
$("install").addEventListener("click",async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$("install").classList.add("hidden");});
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
const saved=localStorage.getItem("humanity2_last");if(saved){latest=saved;$("result").textContent=saved;$("message").textContent="पिछली AI रिपोर्ट इस डिवाइस पर उपलब्ध है।";}
checkServer();
